package com.proeditor.app

import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL

// Talks to the AI service (Groq). Built for weak Wi-Fi: small uploads, long timeouts, automatic retries.
object Net {
    private const val BASE = "https://api.groq.com/openai/v1"

    private fun post(url: String, key: String, type: String, tries: Int, body: (OutputStream) -> Unit): String {
        var last: Exception? = null
        for (a in 1..tries) {
            try {
                val c = URL(url).openConnection() as HttpURLConnection
                c.requestMethod = "POST"
                c.connectTimeout = 30000
                c.readTimeout = 240000
                c.doOutput = true
                c.setRequestProperty("Authorization", "Bearer $key")
                c.setRequestProperty("Content-Type", type)
                c.setChunkedStreamingMode(16384)
                c.outputStream.use { body(it) }
                val code = c.responseCode
                val stream = if (code in 200..299) c.inputStream else c.errorStream
                val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
                if (code in 200..299) return text
                if (code == 401 || code == 403) throw IllegalStateException("The AI key was refused. Check that you pasted it correctly.")
                if (code == 429 || code >= 500) {
                    last = IOException("The AI service is busy ($code)")
                    Thread.sleep(3000L * a)
                    continue
                }
                throw IllegalStateException("The AI service said $code: " + text.take(120))
            } catch (e: IOException) {
                last = e
                Thread.sleep(2500L * a)
            }
        }
        throw last ?: IOException("Network problem")
    }

    // Audio file -> words with exact timings (milliseconds).
    fun transcribe(file: File, key: String): List<Word> {
        val b = "----pe" + System.currentTimeMillis()
        val json = post("$BASE/audio/transcriptions", key, "multipart/form-data; boundary=$b", 4) { o ->
            fun field(n: String, v: String) {
                o.write(("--$b\r\nContent-Disposition: form-data; name=\"$n\"\r\n\r\n$v\r\n").toByteArray())
            }
            field("model", "whisper-large-v3-turbo")
            field("response_format", "verbose_json")
            field("timestamp_granularities[]", "word")
            o.write(("--$b\r\nContent-Disposition: form-data; name=\"file\"; filename=\"audio.m4a\"\r\nContent-Type: audio/mp4\r\n\r\n").toByteArray())
            file.inputStream().use { it.copyTo(o) }
            o.write("\r\n--$b--\r\n".toByteArray())
        }
        val arr = JSONObject(json).optJSONArray("words") ?: JSONArray()
        val out = ArrayList<Word>()
        for (i in 0 until arr.length()) {
            val w = arr.getJSONObject(i)
            val t = w.optString("word").trim()
            if (t.isNotEmpty()) out.add(Word(t, (w.optDouble("start") * 1000).toLong(), (w.optDouble("end") * 1000).toLong()))
        }
        return out
    }

    // Transcript -> the "director's notes": emphasis words, emoji stickers, title, hashtags.
    fun plan(key: String, words: List<Word>, libWords: List<String>): AiPlan {
        val sb = StringBuilder()
        for (i in words.indices) {
            if (i >= 3000) break
            sb.append(i).append(':').append(words[i].t).append(' ')
        }
        val prompt = "You are a professional short-form video editor. Below is a transcript as index:word pairs. " +
            "Reply with JSON only, in this exact shape: " +
            "{\"title\":\"catchy title\",\"description\":\"one sentence\",\"hashtags\":[\"#tag\"],\"library_hits\":[{\"i\":word index,\"keyword\":\"a keyword from the list\"}]," +
            "\"emphasis\":[word indexes of the most important or exciting words, at most one every 5 seconds]," +
            "\"stickers\":[{\"i\":word index,\"emoji\":\"one emoji\"}]}. " +
            "Stickers: pick concrete topics or strong emotions, at most one every 6 seconds, one emoji each. " +
            "library_hits: the user owns pictures tagged with these keywords: " + libWords.joinToString(", ") + ". Return a hit wherever the speaker talks about that keyword's topic, including synonyms or related names, at most one every 4 seconds. Use an empty list if there are no keywords. " +
            "Write the title in the same language as the transcript.\n\nTranscript:\n" + sb
        val body = JSONObject()
            .put("model", "llama-3.3-70b-versatile")
            .put("temperature", 0.4)
            .put("response_format", JSONObject().put("type", "json_object"))
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", prompt)))
            .toString()
        val res = post("$BASE/chat/completions", key, "application/json", 3) { it.write(body.toByteArray()) }
        val content = JSONObject(res).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
        val j = JSONObject(content)
        val emph = HashSet<Int>()
        j.optJSONArray("emphasis")?.let { a -> for (i in 0 until a.length()) emph.add(a.optInt(i, -1)) }
        val st = LinkedHashMap<Int, String>()
        j.optJSONArray("stickers")?.let { a ->
            for (i in 0 until a.length()) {
                val o = a.optJSONObject(i) ?: continue
                val e = o.optString("emoji")
                if (e.isNotEmpty() && e.length <= 8) st[o.optInt("i", -1)] = e
            }
        }
        val tags = ArrayList<String>()
        j.optJSONArray("hashtags")?.let { a -> for (i in 0 until a.length()) tags.add(a.optString(i)) }
        val hits = ArrayList<Pair<Int, String>>()
        j.optJSONArray("library_hits")?.let { a ->
            for (i in 0 until a.length()) {
                val o = a.optJSONObject(i) ?: continue
                hits.add(Pair(o.optInt("i", -1), o.optString("keyword")))
            }
        }
        return AiPlan(j.optString("title"), j.optString("description"), tags, emph, st, hits)
    }
}
