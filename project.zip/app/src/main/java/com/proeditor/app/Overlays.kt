package com.proeditor.app

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.text.SpannableString
import android.text.Spanned
import android.text.style.AbsoluteSizeSpan
import android.text.style.BackgroundColorSpan
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.OverlaySettings
import androidx.media3.effect.TextOverlay

// Word-by-word captions: the word being said lights up.
class CaptionOverlay(
    private val phrases: List<Phrase>,
    private val sizePx: Int,
    private val style: Int,
    private val yAnchor: Float
) : TextOverlay() {
    private val blank = SpannableString(" ")
    private val cache = HashMap<Int, SpannableString>()
    private val hl = intArrayOf(0xFFFFE14D.toInt(), 0xFFFFFFFF.toInt(), 0xFF00E676.toInt())

    private fun find(tMs: Long): Phrase? {
        var r: Phrase? = null
        for (p in phrases) {
            if (p.s > tMs) break
            if (tMs <= p.e) r = p
        }
        return r
    }

    private fun disp(t: String) = t.filter { it.isLetterOrDigit() || it == '\'' }.uppercase()

    private fun build(p: Phrase, wi: Int): SpannableString {
        val parts = p.words.map { disp(it.t) }
        val sp = SpannableString(parts.joinToString(" "))
        sp.setSpan(AbsoluteSizeSpan(sizePx), 0, sp.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        sp.setSpan(StyleSpan(Typeface.BOLD), 0, sp.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        sp.setSpan(BackgroundColorSpan(0x99000000.toInt()), 0, sp.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        var pos = 0
        for ((k, d) in parts.withIndex()) {
            val c = if (k == wi) hl[style % 3] else Color.WHITE
            if (d.isNotEmpty()) sp.setSpan(ForegroundColorSpan(c), pos, pos + d.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            pos += d.length + 1
        }
        return sp
    }

    override fun getText(presentationTimeUs: Long): SpannableString {
        val t = presentationTimeUs / 1000
        val p = find(t) ?: return blank
        var wi = 0
        for (k in p.words.indices) if (p.outStarts[k] <= t) wi = k
        return cache.getOrPut(p.id * 10 + wi) { build(p, wi) }
    }

    override fun getOverlaySettings(presentationTimeUs: Long): OverlaySettings {
        val vis = find(presentationTimeUs / 1000) != null
        return OverlaySettings.Builder()
            .setBackgroundFrameAnchor(0f, yAnchor)
            .setOverlayFrameAnchor(0f, 0f)
            .setAlphaScale(if (vis) 1f else 0f)
            .build()
    }
}

// Emoji stickers that pop in, wiggle to size, and fade out.
class EmojiOverlay(private val stickers: List<Sticker>, private val sizePx: Int) : TextOverlay() {
    private val blank = SpannableString(" ")
    private val cache = HashMap<String, SpannableString>()

    private fun find(t: Long): Sticker? {
        var r: Sticker? = null
        for (s in stickers) if (t >= s.s && t < s.s + 1600) r = s
        return r
    }

    override fun getText(presentationTimeUs: Long): SpannableString {
        val s = find(presentationTimeUs / 1000) ?: return blank
        return cache.getOrPut(s.emoji) {
            SpannableString(s.emoji).also { it.setSpan(AbsoluteSizeSpan(sizePx), 0, it.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE) }
        }
    }

    override fun getOverlaySettings(presentationTimeUs: Long): OverlaySettings {
        val t = presentationTimeUs / 1000
        val s = find(t) ?: return OverlaySettings.Builder().setAlphaScale(0f).build()
        val age = t - s.s
        val scale = when {
            age < 220 -> 0.3f + 0.95f * (age / 220f)
            age < 380 -> 1.25f - 0.25f * ((age - 220) / 160f)
            else -> 1f
        }
        val alpha = if (age > 1350) (1600 - age) / 250f else 1f
        val x = if ((s.s / 1000) % 2 == 0L) 0.55f else -0.55f
        return OverlaySettings.Builder()
            .setBackgroundFrameAnchor(x, 0.4f)
            .setOverlayFrameAnchor(0f, 0f)
            .setScale(scale, scale)
            .setAlphaScale(alpha.coerceIn(0f, 1f))
            .build()
    }
}

// Your own pictures (green screen already removed) that pop in when the topic is mentioned.
class ImageOverlay(private val items: List<ImgSticker>, private val bmps: List<Bitmap?>) : BitmapOverlay() {
    private val blank: Bitmap = Bitmap.createBitmap(2, 2, Bitmap.Config.ARGB_8888)

    private fun find(t: Long): ImgSticker? {
        var r: ImgSticker? = null
        for (s in items) if (t >= s.s && t < s.s + 2000) r = s
        return r
    }

    override fun getBitmap(presentationTimeUs: Long): Bitmap {
        val s = find(presentationTimeUs / 1000) ?: return blank
        return bmps.getOrNull(s.item) ?: blank
    }

    override fun getOverlaySettings(presentationTimeUs: Long): OverlaySettings {
        val t = presentationTimeUs / 1000
        val s = find(t) ?: return OverlaySettings.Builder().setAlphaScale(0f).build()
        val age = t - s.s
        val scale = when {
            age < 240 -> 0.4f + 0.85f * (age / 240f)
            age < 420 -> 1.25f - 0.25f * ((age - 240) / 180f)
            else -> 1f
        }
        val alpha = if (age > 1700) (2000 - age) / 300f else 1f
        val x = if ((s.s / 1000) % 2 == 0L) -0.5f else 0.5f
        return OverlaySettings.Builder()
            .setBackgroundFrameAnchor(x, 0.3f)
            .setOverlayFrameAnchor(0f, 0f)
            .setScale(scale, scale)
            .setAlphaScale(alpha.coerceIn(0f, 1f))
            .build()
    }
}
