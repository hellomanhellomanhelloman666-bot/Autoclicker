package com.proeditor.app

class Word(val t: String, val s: Long, val e: Long)

class Piece(var s: Long, var e: Long, val zoom: Boolean) {
    var outS = 0L
}

class Phrase(val id: Int, val words: List<Word>, val outStarts: List<Long>, val s: Long, val e: Long)

class Sticker(val s: Long, val emoji: String)

class AiPlan(val title: String, val desc: String, val tags: List<String>, val emphasis: Set<Int>, val stickers: Map<Int, String>, val hits: List<Pair<Int, String>>)

class ImgSticker(val s: Long, val item: Int)

class Edit(val pieces: List<Piece>, val phrases: List<Phrase>, val stickers: List<Sticker>, val images: List<ImgSticker>, val totalMs: Long)

// The "director": turns words + AI notes into a cut list, captions, zooms and stickers.
object Director {
    private val FILL = setOf("um", "uh", "umm", "uhh", "erm", "hmm", "ah", "eh", "emm", "uhm", "mhm")
    private val EMOJI = mapOf(
        "apple" to "🍎", "money" to "💰", "dollar" to "💵", "fire" to "🔥", "love" to "❤️", "game" to "🎮", "diamond" to "💎",
        "zombie" to "🧟", "sword" to "⚔️", "creeper" to "💥", "boom" to "💥", "explosion" to "💥", "gold" to "🥇", "crown" to "👑",
        "music" to "🎵", "phone" to "📱", "car" to "🚗", "rocket" to "🚀", "star" to "⭐", "heart" to "❤️", "laugh" to "😂",
        "funny" to "😂", "wow" to "😮", "amazing" to "🤩", "crazy" to "🤯", "secret" to "🤫", "time" to "⏰", "idea" to "💡",
        "win" to "🏆", "won" to "🏆", "dead" to "💀", "die" to "💀", "water" to "💧", "lava" to "🌋", "cake" to "🍰", "pizza" to "🍕",
        "dog" to "🐶", "cat" to "🐱", "house" to "🏠", "world" to "🌍", "hot" to "🥵", "cold" to "🥶", "sleep" to "😴", "angry" to "😡"
    )

    private fun clean(s: String) = s.lowercase().filter { it.isLetterOrDigit() }

    private fun matches(a: String, b: String): Boolean = Library.variants(a).any { x -> x.isNotEmpty() && Library.variants(b).contains(x) }

    fun build(words: List<Word>, durMs: Long, ai: AiPlan?, cut: Boolean, zoom: Boolean, wantStickers: Boolean, lib: List<Item>): Edit {
        val keep = words.indices.filter { clean(words[it].t).isNotEmpty() && !(cut && clean(words[it].t) in FILL) }
        val segs = ArrayList<LongArray>()
        if (cut && keep.isNotEmpty()) {
            for (i in keep) {
                val w = words[i]
                val s = maxOf(0L, w.s - 70)
                val e = minOf(durMs, w.e + 130)
                val l = segs.lastOrNull()
                if (l != null && s - l[1] < 450) l[1] = maxOf(l[1], e) else segs.add(longArrayOf(s, e))
            }
        } else segs.add(longArrayOf(0L, durMs))

        var emph: List<Int> = ai?.emphasis?.sorted() ?: emptyList()
        if (emph.isEmpty()) {            // no AI notes: pick long, meaningful words roughly every 5 seconds
            val pick = ArrayList<Int>()
            var last = -9999L
            for (i in keep) if (clean(words[i].t).length >= 7 && words[i].s - last > 5000) {
                pick.add(i)
                last = words[i].s
            }
            emph = pick
        }
        var pieces = pieces(segs, words, emph, zoom)
        if (pieces.size > 140) pieces = pieces(segs, words, emph, false)
        var t = 0L
        for (p in pieces) {
            p.outS = t
            t += p.e - p.s
        }
        fun outOf(ms: Long): Long? {
            for (p in pieces) if (ms >= p.s && ms < p.e) return p.outS + (ms - p.s)
            return null
        }

        val phrases = ArrayList<Phrase>()
        var cur = ArrayList<Int>()
        fun flush() {
            if (cur.isEmpty()) return
            val ws = cur.map { words[it] }
            val os = ws.map { outOf(it.s) ?: -1L }
            if (os.all { it >= 0 }) {
                val end = (outOf(ws.last().e - 1) ?: (os.last() + (ws.last().e - ws.last().s))) + 120
                phrases.add(Phrase(phrases.size, ws, os, os[0], end))
            }
            cur = ArrayList()
        }
        for ((n, i) in keep.withIndex()) {
            cur.add(i)
            val tx = words[i].t.trim()
            val punct = tx.endsWith(".") || tx.endsWith("?") || tx.endsWith("!") || tx.endsWith(",")
            val gap = n + 1 < keep.size && words[keep[n + 1]].s - words[i].e > 400
            if (cur.size >= 3 || punct || gap) flush()
        }
        flush()

        val stickers = ArrayList<Sticker>()
        if (wantStickers) {
            val found = ArrayList<Pair<Int, String>>()
            if (ai != null) for ((i, e) in ai.stickers) if (i in words.indices) found.add(Pair(i, e))
            if (found.isEmpty()) for (i in keep) EMOJI[clean(words[i].t)]?.let { found.add(Pair(i, it)) }
            found.sortBy { it.first }
            var lastOut = -9999L
            for ((i, e) in found) {
                val o = outOf(words[i].s) ?: continue
                if (o - lastOut >= 3500) {
                    stickers.add(Sticker(o, e))
                    lastOut = o
                }
            }
        }
        // Your own pictures (for example a green-screen apple) pop up when the speaker talks about them.
        val images = ArrayList<ImgSticker>()
        if (lib.isNotEmpty()) {
            val cand = ArrayList<Pair<Int, Int>>()
            if (ai != null) for ((i, k) in ai.hits) {
                val ii = lib.indexOfFirst { it.words.any { w -> matches(w, k) } }
                if (ii >= 0 && i in words.indices) cand.add(Pair(i, ii))
            }
            for (i in keep) for ((ii, item) in lib.withIndex()) if (item.words.any { matches(it, words[i].t) }) cand.add(Pair(i, ii))
            cand.sortBy { it.first }
            val lastFor = HashMap<Int, Long>()
            var lastAny = -9999L
            for ((i, ii) in cand) {
                val o = outOf(words[i].s) ?: continue
                if (o - (lastFor[ii] ?: -9999L) >= 3500 && o - lastAny >= 1500) {
                    images.add(ImgSticker(o, ii))
                    lastFor[ii] = o
                    lastAny = o
                }
            }
            stickers.removeAll { s -> images.any { im -> s.s >= im.s - 300 && s.s <= im.s + 2300 } }
        }
        return Edit(pieces, phrases, stickers, images, t)
    }

    private fun pieces(segs: List<LongArray>, words: List<Word>, emph: List<Int>, zoom: Boolean): ArrayList<Piece> {
        val out = ArrayList<Piece>()
        for (sg in segs) {
            if (sg[1] - sg[0] < 150) continue
            val wins = ArrayList<LongArray>()
            if (zoom) for (i in emph) {
                if (i < 0 || i >= words.size) continue
                val w = words[i]
                if (w.s >= sg[0] && w.s < sg[1]) {
                    val a = maxOf(sg[0], w.s - 150)
                    val b = minOf(sg[1], maxOf(w.e + 450, a + 900))
                    val l = wins.lastOrNull()
                    if (l != null && a <= l[1]) l[1] = maxOf(l[1], b) else wins.add(longArrayOf(a, b))
                }
            }
            var pos = sg[0]
            for (w in wins) {
                var a = maxOf(w[0], pos)
                if (a - pos >= 300) out.add(Piece(pos, a, false)) else a = pos
                if (w[1] - a >= 300) {
                    out.add(Piece(a, w[1], true))
                    pos = w[1]
                } else pos = a
            }
            if (sg[1] - pos >= 200) out.add(Piece(pos, sg[1], false))
            else if (out.isNotEmpty() && out.last().e == pos) out.last().e = sg[1]
        }
        return out
    }

    // Offline mode: only the quiet-part cuts, with alternating zoom (jump-cut style).
    fun fromSegments(segs: List<LongArray>, zoom: Boolean): Edit {
        var kept = 0L
        for (s in segs) kept += s[1] - s[0]
        val chunk = maxOf(4000L, kept / 40)
        val out = ArrayList<Piece>()
        var n = 0
        for (s in segs) {
            if (zoom && s[1] - s[0] > chunk * 3 / 2) {
                var a = s[0]
                while (a < s[1]) {
                    var b = minOf(a + chunk, s[1])
                    if (s[1] - b < chunk / 2) b = s[1]
                    out.add(Piece(a, b, n % 2 == 1))
                    n++
                    a = b
                }
            } else {
                out.add(Piece(s[0], s[1], zoom && n % 2 == 1))
                n++
            }
        }
        var t = 0L
        for (p in out) {
            p.outS = t
            t += p.e - p.s
        }
        return Edit(out, emptyList(), emptyList(), emptyList(), t)
    }
}
