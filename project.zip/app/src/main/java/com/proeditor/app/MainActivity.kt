package com.proeditor.app

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.graphics.Color
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.MediaController
import android.widget.ProgressBar
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.effect.Contrast
import androidx.media3.effect.HslAdjustment
import androidx.media3.effect.Presentation
import androidx.media3.effect.RgbAdjustment
import androidx.media3.effect.ScaleAndRotateTransformation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import java.io.File

class MainActivity : Activity() {
    private var src: Uri? = null
    private var durMs = 0L
    private var transformer: Transformer? = null
    private var outFile: File? = null
    private var savedUri: Uri? = null
    private var startedAt = 0L
    private var busy = false
    private val handler = Handler(Looper.getMainLooper())

    private lateinit var info: TextView
    private lateinit var status: TextView
    private lateinit var spinner: ProgressBar
    private lateinit var video: VideoView
    private lateinit var btnMake: Button
    private lateinit var btnCancel: Button
    private lateinit var btnSave: Button
    private lateinit var btnShare: Button
    private lateinit var fmtG: RadioGroup
    private lateinit var lookG: RadioGroup
    private lateinit var cutCb: CheckBox
    private lateinit var zoomCb: CheckBox

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(t: String) = TextView(this).apply {
        text = t
        textSize = 16f
        setTextColor(0xFFB8C2D6.toInt())
        setPadding(0, dp(16), 0, dp(4))
    }

    private fun button(t: String, f: () -> Unit) = Button(this).apply {
        text = t
        isAllCaps = false
        setOnClickListener { f() }
    }

    private fun radios(items: List<String>): RadioGroup {
        val g = RadioGroup(this)
        items.forEachIndexed { i, t ->
            val r = RadioButton(this)
            r.id = View.generateViewId()
            r.text = t
            r.setTextColor(Color.WHITE)
            g.addView(r)
            if (i == 0) r.isChecked = true
        }
        return g
    }

    private fun idx(g: RadioGroup): Int = g.indexOfChild(g.findViewById(g.checkedRadioButtonId))

    private fun check(t: String) = CheckBox(this).apply {
        text = t
        isChecked = true
        setTextColor(Color.WHITE)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(18), dp(28), dp(18), dp(40))
        val sv = ScrollView(this)
        sv.setBackgroundColor(0xFF12161C.toInt())
        sv.addView(root)
        setContentView(sv)

        val title = TextView(this)
        title.text = "Pro Editor"
        title.textSize = 26f
        title.setTextColor(Color.WHITE)
        root.addView(title)
        val sub = TextView(this)
        sub.text = "Pick a raw video. It cuts the boring parts, adds punch-in zooms, fixes the colors and gets it ready for TikTok or YouTube. Works offline."
        sub.setTextColor(0xFF8D98A9.toInt())
        root.addView(sub)

        root.addView(label("1. Your video"))
        root.addView(button("Pick a video") {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            i.addCategory(Intent.CATEGORY_OPENABLE)
            i.type = "video/*"
            startActivityForResult(i, 1)
        })
        info = TextView(this)
        info.setTextColor(Color.WHITE)
        info.text = "No video yet"
        root.addView(info)

        root.addView(label("2. Format"))
        fmtG = radios(listOf("TikTok / Reels / Shorts (9:16)", "YouTube (16:9)", "Keep the original shape"))
        root.addView(fmtG)
        root.addView(label("3. Look"))
        lookG = radios(listOf("No color change", "Vibrant (TikTok pop)", "Cinematic", "Minecraft pop"))
        root.addView(lookG)
        root.addView(label("4. Smart edits"))
        cutCb = check("Cut silent / boring parts")
        zoomCb = check("Punch-in zooms (jump-cut style)")
        root.addView(cutCb)
        root.addView(zoomCb)

        btnMake = button("Make it pro") { make() }
        root.addView(btnMake)
        spinner = ProgressBar(this)
        spinner.visibility = View.GONE
        root.addView(spinner)
        status = TextView(this)
        status.setTextColor(0xFF7EE787.toInt())
        status.setPadding(0, dp(8), 0, dp(8))
        root.addView(status)
        btnCancel = button("Cancel") { cancel() }
        btnCancel.visibility = View.GONE
        root.addView(btnCancel)

        video = VideoView(this)
        video.visibility = View.GONE
        root.addView(video, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(380)))
        btnSave = button("Save to gallery") { save(false) }
        btnShare = button("Share") { save(true) }
        btnSave.visibility = View.GONE
        btnShare.visibility = View.GONE
        root.addView(btnSave)
        root.addView(btnShare)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 1 || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            val r = MediaMetadataRetriever()
            r.setDataSource(this, uri)
            durMs = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            r.release()
        } catch (e: Exception) {
            durMs = 0L
        }
        if (durMs <= 0L) {
            Toast.makeText(this, "I could not read this video", Toast.LENGTH_LONG).show()
            return
        }
        src = uri
        var name = "video"
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0 && c.moveToFirst()) name = c.getString(i)
        }
        info.text = name + "  •  " + fmt(durMs)
        video.visibility = View.GONE
        btnSave.visibility = View.GONE
        btnShare.visibility = View.GONE
        status.text = ""
    }

    private fun fmt(ms: Long): String {
        val s = ms / 1000
        return (s / 60).toString() + ":" + (s % 60).toString().padStart(2, '0')
    }

    private fun setBusy(b: Boolean, msg: String) {
        busy = b
        spinner.visibility = if (b) View.VISIBLE else View.GONE
        btnCancel.visibility = if (b) View.VISIBLE else View.GONE
        btnMake.isEnabled = !b
        status.text = msg
        if (b) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun make() {
        val uri = src
        if (uri == null) {
            Toast.makeText(this, "Pick a video first", Toast.LENGTH_SHORT).show()
            return
        }
        video.visibility = View.GONE
        btnSave.visibility = View.GONE
        btnShare.visibility = View.GONE
        savedUri = null
        setBusy(true, "Listening to your video...")
        val cut = cutCb.isChecked
        Thread {
            val segs: List<LongArray> = try {
                if (cut) Analyzer.plan(this, uri, durMs) else listOf(longArrayOf(0L, durMs))
            } catch (e: Exception) {
                listOf(longArrayOf(0L, durMs))
            }
            runOnUiThread { export(uri, segs) }
        }.start()
    }

    private fun export(uri: Uri, segs: List<LongArray>) {
        var kept = 0L
        for (s in segs) kept += s[1] - s[0]
        val zoom = zoomCb.isChecked
        val chunk = maxOf(4000L, kept / 40)
        val pieces = ArrayList<LongArray>()
        for (s in segs) {
            if (zoom && s[1] - s[0] > chunk * 3 / 2) {
                var a = s[0]
                while (a < s[1]) {
                    var b = minOf(a + chunk, s[1])
                    if (s[1] - b < chunk / 2) b = s[1]
                    pieces.add(longArrayOf(a, b))
                    a = b
                }
            } else pieces.add(s)
        }
        val items = ArrayList<EditedMediaItem>()
        pieces.forEachIndexed { i, p ->
            val mb = MediaItem.Builder().setUri(uri)
            if (!(p[0] == 0L && p[1] >= durMs)) {
                mb.setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(p[0])
                        .setEndPositionMs(p[1])
                        .build()
                )
            }
            val eb = EditedMediaItem.Builder(mb.build())
            if (zoom && i % 2 == 1) {
                val z = ArrayList<Effect>()
                z.add(ScaleAndRotateTransformation.Builder().setScale(1.15f, 1.15f).build())
                eb.setEffects(Effects(emptyList(), z))
            }
            items.add(eb.build())
        }
        val fx = ArrayList<Effect>()
        when (idx(fmtG)) {
            0 -> fx.add(Presentation.createForWidthAndHeight(1080, 1920, Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP))
            1 -> fx.add(Presentation.createForWidthAndHeight(1920, 1080, Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP))
        }
        when (idx(lookG)) {
            1 -> {
                fx.add(Contrast(0.15f))
                fx.add(HslAdjustment.Builder().adjustSaturation(22f).build())
            }
            2 -> {
                fx.add(Contrast(0.2f))
                fx.add(HslAdjustment.Builder().adjustSaturation(6f).build())
                fx.add(RgbAdjustment.Builder().setRedScale(1.05f).setBlueScale(0.95f).build())
            }
            3 -> {
                fx.add(Contrast(0.12f))
                fx.add(HslAdjustment.Builder().adjustSaturation(35f).adjustLightness(4f).build())
            }
        }
        val composition = Composition.Builder(EditedMediaItemSequence(items))
            .setEffects(Effects(emptyList(), fx))
            .build()
        val out = File(cacheDir, "proedit_" + System.currentTimeMillis() + ".mp4")
        outFile?.delete()
        outFile = out
        val removed = durMs - kept
        val note = if (removed > 1500) "Cut " + fmt(removed) + " of quiet parts. " else ""
        startedAt = System.currentTimeMillis()
        setBusy(true, note + "Editing... keep the app open")
        tick()
        val t = Transformer.Builder(this)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    setBusy(false, "Done! " + note + "Preview below.")
                    video.visibility = View.VISIBLE
                    btnSave.visibility = View.VISIBLE
                    btnShare.visibility = View.VISIBLE
                    video.setVideoPath(out.absolutePath)
                    video.setMediaController(MediaController(this@MainActivity))
                    video.start()
                }

                override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                    setBusy(false, "Could not edit this video: " + exportException.message)
                }
            })
            .build()
        transformer = t
        t.start(composition, out.absolutePath)
    }

    private fun tick() {
        if (!busy) return
        val s = (System.currentTimeMillis() - startedAt) / 1000
        val t = status.text.toString().substringBefore("  (")
        status.text = t + "  (" + s + "s)"
        handler.postDelayed({ tick() }, 1000)
    }

    private fun cancel() {
        transformer?.cancel()
        setBusy(false, "Cancelled")
    }

    private fun save(share: Boolean) {
        var uri = savedUri
        if (uri == null) {
            val f = outFile ?: return
            val v = ContentValues()
            v.put(MediaStore.Video.Media.DISPLAY_NAME, "ProEdit_" + System.currentTimeMillis() + ".mp4")
            v.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            v.put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/ProEdit")
            v.put(MediaStore.Video.Media.IS_PENDING, 1)
            uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v)
            if (uri == null) {
                Toast.makeText(this, "Could not save", Toast.LENGTH_LONG).show()
                return
            }
            contentResolver.openOutputStream(uri)?.use { o -> f.inputStream().use { it.copyTo(o) } }
            v.clear()
            v.put(MediaStore.Video.Media.IS_PENDING, 0)
            contentResolver.update(uri, v, null, null)
            savedUri = uri
            Toast.makeText(this, "Saved in Movies/ProEdit", Toast.LENGTH_SHORT).show()
        }
        if (share) {
            val i = Intent(Intent.ACTION_SEND)
            i.type = "video/mp4"
            i.putExtra(Intent.EXTRA_STREAM, uri)
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(i, "Share video"))
        }
    }

    override fun onDestroy() {
        busy = false
        transformer?.cancel()
        super.onDestroy()
    }
}
