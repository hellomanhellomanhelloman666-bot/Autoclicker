package com.proeditor.app

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.text.InputType
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.MediaController
import android.widget.ProgressBar
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.effect.Contrast
import androidx.media3.effect.HslAdjustment
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.Presentation
import androidx.media3.effect.RgbAdjustment
import androidx.media3.effect.ScaleAndRotateTransformation
import androidx.media3.effect.TextureOverlay
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import com.google.common.collect.ImmutableList
import java.io.File

class MainActivity : Activity() {
    private var src: Uri? = null
    private var durMs = 0L
    private var vw = 1920
    private var vh = 1080
    private var transformer: Transformer? = null
    private var outFile: File? = null
    private var savedUri: Uri? = null
    private var startedAt = 0L
    private var busy = false
    private var resultText = ""
    private val handler = Handler(Looper.getMainLooper())

    private lateinit var keyEt: EditText
    private lateinit var info: TextView
    private lateinit var status: TextView
    private lateinit var result: TextView
    private lateinit var spinner: ProgressBar
    private lateinit var video: VideoView
    private lateinit var btnMake: Button
    private lateinit var btnCancel: Button
    private lateinit var btnSave: Button
    private lateinit var btnShare: Button
    private lateinit var btnCopy: Button
    private lateinit var fmtG: RadioGroup
    private lateinit var lookG: RadioGroup
    private lateinit var capG: RadioGroup
    private lateinit var capCb: CheckBox
    private lateinit var stickCb: CheckBox
    private lateinit var cutCb: CheckBox
    private lateinit var zoomCb: CheckBox
    private lateinit var libInfo: TextView
    private var libCache: List<Item> = emptyList()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(t: String) = TextView(this).apply {
        text = t
        textSize = 16f
        setTextColor(0xFFB8C2D6.toInt())
        setPadding(0, dp(16), 0, dp(4))
    }

    private fun button(t: String, f: () -> Unit) = Button(this).apply {
        text = t
        isAllCaps = false
        setOnClickListener { f() }
    }

    private fun radios(items: List<String>): RadioGroup {
        val g = RadioGroup(this)
        items.forEachIndexed { i, t ->
            val r = RadioButton(this)
            r.id = View.generateViewId()
            r.text = t
            r.setTextColor(Color.WHITE)
            g.addView(r)
            if (i == 0) r.isChecked = true
        }
        return g
    }

    private fun idx(g: RadioGroup): Int = g.indexOfChild(g.findViewById(g.checkedRadioButtonId))

    private fun check(t: String) = CheckBox(this).apply {
        text = t
        isChecked = true
        setTextColor(Color.WHITE)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(18), dp(28), dp(18), dp(40))
        val sv = ScrollView(this)
        sv.setBackgroundColor(0xFF12161C.toInt())
        sv.addView(root)
        setContentView(sv)

        val title = TextView(this)
        title.text = "Pro Editor AI"
        title.textSize = 26f
        title.setTextColor(Color.WHITE)
        root.addView(title)
        val sub = TextView(this)
        sub.text = "The AI listens to your video, writes word-by-word captions, cuts silences and filler words, zooms on key words and adds emoji stickers. Only the small audio track is uploaded, never the video. Without internet it still cuts and zooms."
        sub.setTextColor(0xFF8D98A9.toInt())
        root.addView(sub)

        root.addView(label("AI key (free from console.groq.com)"))
        keyEt = EditText(this)
        keyEt.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        keyEt.hint = "Paste your key here"
        keyEt.setTextColor(Color.WHITE)
        keyEt.setHintTextColor(0xFF667389.toInt())
        keyEt.setText(getSharedPreferences("pe", 0).getString("key", "") ?: "")
        root.addView(keyEt)
        root.addView(button("Save key") {
            getSharedPreferences("pe", 0).edit().putString("key", keyEt.text.toString().trim()).apply()
            Toast.makeText(this, "Saved on this phone only", Toast.LENGTH_SHORT).show()
        })

        root.addView(label("1. Your video"))
        root.addView(button("Pick a video") {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            i.addCategory(Intent.CATEGORY_OPENABLE)
            i.type = "video/*"
            startActivityForResult(i, 1)
        })
        info = TextView(this)
        info.setTextColor(Color.WHITE)
        info.text = "No video yet"
        root.addView(info)

        root.addView(label("2. Format"))
        fmtG = radios(listOf("TikTok / Reels / Shorts (9:16)", "YouTube (16:9)", "Keep the original shape"))
        root.addView(fmtG)
        root.addView(label("3. Color look"))
        lookG = radios(listOf("No color change", "Vibrant (TikTok pop)", "Cinematic", "Minecraft pop"))
        root.addView(lookG)
        root.addView(label("4. AI edits"))
        capCb = check("Word-by-word captions")
        stickCb = check("Emoji stickers on key moments")
        cutCb = check("Cut silences and filler words (um, uh)")
        zoomCb = check("Smart zooms on important words")
        root.addView(capCb)
        root.addView(stickCb)
        root.addView(cutCb)
        root.addView(zoomCb)
        root.addView(label("My stickers (green screen works too)"))
        val lt = TextView(this)
        lt.text = "Add your own pictures, for example a green-screen apple tagged with the word apple. When the speaker talks about it, the picture pops up and the green is removed automatically."
        lt.setTextColor(0xFF8D98A9.toInt())
        root.addView(lt)
        root.addView(button("Add a sticker or green-screen picture") {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            i.addCategory(Intent.CATEGORY_OPENABLE)
            i.type = "image/*"
            startActivityForResult(i, 2)
        })
        root.addView(button("Remove a sticker") { removeSticker() })
        libInfo = TextView(this)
        libInfo.setTextColor(Color.WHITE)
        root.addView(libInfo)
        refreshLib()
        root.addView(label("Caption style"))
        capG = radios(listOf("Yellow pop", "White clean", "Green hype"))
        root.addView(capG)

        btnMake = button("Make it pro with AI") { make() }
        root.addView(btnMake)
        spinner = ProgressBar(this)
        spinner.visibility = View.GONE
        root.addView(spinner)
        status = TextView(this)
        status.setTextColor(0xFF7EE787.toInt())
        status.setPadding(0, dp(8), 0, dp(8))
        root.addView(status)
        btnCancel = button("Cancel") { cancel() }
        btnCancel.visibility = View.GONE
        root.addView(btnCancel)

        video = VideoView(this)
        video.visibility = View.GONE
        root.addView(video, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(400)))
        result = TextView(this)
        result.setTextColor(Color.WHITE)
        result.setTextIsSelectable(true)
        result.setPadding(0, dp(10), 0, dp(6))
        root.addView(result)
        btnCopy = button("Copy title and hashtags") {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("post", resultText))
            Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show()
        }
        btnSave = button("Save to gallery") { save(false) }
        btnShare = button("Share") { save(true) }
        for (b in listOf(btnCopy, btnSave, btnShare)) {
            b.visibility = View.GONE
            root.addView(b)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 2 && resultCode == RESULT_OK) {
            data?.data?.let { addSticker(it) }
            return
        }
        if (requestCode != 1 || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            val r = MediaMetadataRetriever()
            r.setDataSource(this, uri)
            durMs = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            val w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 1920
            val h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 1080
            val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            r.release()
            if (rot == 90 || rot == 270) {
                vw = h
                vh = w
            } else {
                vw = w
                vh = h
            }
        } catch (e: Exception) {
            durMs = 0L
        }
        if (durMs <= 0L) {
            Toast.makeText(this, "I could not read this video", Toast.LENGTH_LONG).show()
            return
        }
        src = uri
        var name = "video"
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0 && c.moveToFirst()) name = c.getString(i)
        }
        info.text = name + "  •  " + fmt(durMs)
        hideResult()
        status.text = ""
    }

    private fun refreshLib() {
        val l = Library.load(this)
        libInfo.text = if (l.isEmpty()) "No stickers yet" else l.mapIndexed { i, x -> (i + 1).toString() + ". " + x.words.joinToString(", ") }.joinToString("\n")
    }

    private fun addSticker(uri: Uri) {
        val bmp = Library.decode(this, uri, 700)
        if (bmp == null) {
            Toast.makeText(this, "I could not read this picture", Toast.LENGTH_LONG).show()
            return
        }
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(10), dp(20), 0)
        val et = EditText(this)
        et.hint = "Trigger words, like: apple, iphone"
        val cb = CheckBox(this)
        cb.text = "Remove the green background"
        cb.isChecked = Library.greenCorners(bmp)
        box.addView(et)
        box.addView(cb)
        AlertDialog.Builder(this)
            .setTitle("When should it appear?")
            .setView(box)
            .setPositiveButton("Add") { _, _ ->
                val words = et.text.toString().split(Regex("[,،\\s]+")).map { it.trim() }.filter { it.isNotEmpty() }
                if (words.isEmpty()) {
                    Toast.makeText(this, "Type at least one word", Toast.LENGTH_LONG).show()
                } else {
                    Library.add(this, if (cb.isChecked) Library.chroma(bmp) else bmp, words)
                    refreshLib()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun removeSticker() {
        val l = Library.load(this)
        if (l.isEmpty()) return
        AlertDialog.Builder(this)
            .setTitle("Remove which one?")
            .setItems(l.map { it.words.joinToString(", ") }.toTypedArray()) { _, i ->
                Library.remove(this, i)
                refreshLib()
            }
            .show()
    }

    private fun hideResult() {
        video.visibility = View.GONE
        result.text = ""
        for (b in listOf(btnCopy, btnSave, btnShare)) b.visibility = View.GONE
    }

    private fun fmt(ms: Long): String {
        val s = ms / 1000
        return (s / 60).toString() + ":" + (s % 60).toString().padStart(2, '0')
    }

    private fun setBusy(b: Boolean, msg: String) {
        busy = b
        spinner.visibility = if (b) View.VISIBLE else View.GONE
        btnCancel.visibility = if (b) View.VISIBLE else View.GONE
        btnMake.isEnabled = !b
        status.text = msg
        if (b) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun say(msg: String) = runOnUiThread { if (busy) status.text = msg }

    private fun make() {
        val uri = src
        if (uri == null) {
            Toast.makeText(this, "Pick a video first", Toast.LENGTH_SHORT).show()
            return
        }
        hideResult()
        savedUri = null
        libCache = Library.load(this)
        startedAt = System.currentTimeMillis()
        val key = keyEt.text.toString().trim()
        getSharedPreferences("pe", 0).edit().putString("key", key).apply()
        if (key.isEmpty()) {
            setBusy(true, "No AI key, so I will use offline mode (cuts and zooms only)...")
            tick()
            offline(uri, "")
            return
        }
        setBusy(true, "1/4  Getting the audio...")
        tick()
        val audio = File(cacheDir, "audio.m4a")
        audio.delete()
        val t = Transformer.Builder(this)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    runAi(uri, key, audio)
                }

                override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                    offline(uri, "Could not read the audio (" + exportException.message + "). ")
                }
            })
            .build()
        transformer = t
        t.start(EditedMediaItem.Builder(MediaItem.fromUri(uri)).setRemoveVideo(true).build(), audio.absolutePath)
    }

    private fun runAi(uri: Uri, key: String, audio: File) {
        val mb = String.format("%.1f", audio.length() / 1048576.0)
        say("2/4  Sending " + mb + " MB of audio to the AI (weak Wi-Fi is OK, it retries)...")
        Thread {
            try {
                val words = Net.transcribe(audio, key)
                if (words.isEmpty()) throw IllegalStateException("I could not hear any speech")
                say("3/4  The AI is planning your edit (" + words.size + " words)...")
                val plan: AiPlan? = try {
                    Net.plan(key, words, libCache.flatMap { it.words })
                } catch (e: Exception) {
                    if (e is IllegalStateException && (e.message ?: "").contains("key")) throw e
                    null
                }
                val edit = Director.build(words, durMs, plan, cutCb.isChecked, zoomCb.isChecked, stickCb.isChecked, libCache)
                runOnUiThread { export(uri, edit, plan, if (plan == null) "AI notes unavailable, used basic rules. " else "") }
            } catch (e: Exception) {
                runOnUiThread { offline(uri, "AI step failed: " + e.message + ". ") }
            }
        }.start()
    }

    private fun offline(uri: Uri, why: String) {
        Thread {
            val segs: List<LongArray> = try {
                if (cutCb.isChecked) Analyzer.plan(this, uri, durMs) else listOf(longArrayOf(0L, durMs))
            } catch (e: Exception) {
                listOf(longArrayOf(0L, durMs))
            }
            val edit = Director.fromSegments(segs, zoomCb.isChecked)
            runOnUiThread { export(uri, edit, null, why + "Offline mode. ") }
        }.start()
    }

    private fun export(uri: Uri, edit: Edit, plan: AiPlan?, note0: String) {
        val items = ArrayList<EditedMediaItem>()
        for (p in edit.pieces) {
            val mb = MediaItem.Builder().setUri(uri)
            if (!(p.s == 0L && p.e >= durMs)) {
                mb.setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder().setStartPositionMs(p.s).setEndPositionMs(p.e).build()
                )
            }
            val eb = EditedMediaItem.Builder(mb.build())
            if (p.zoom) {
                val z = ArrayList<Effect>()
                z.add(ScaleAndRotateTransformation.Builder().setScale(1.15f, 1.15f).build())
                eb.setEffects(Effects(emptyList(), z))
            }
            items.add(eb.build())
        }
        if (items.isEmpty()) {
            setBusy(false, "Nothing to edit: the video seems empty.")
            return
        }
        val fx = ArrayList<Effect>()
        val f = idx(fmtG)
        when (f) {
            0 -> fx.add(Presentation.createForWidthAndHeight(1080, 1920, Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP))
            1 -> fx.add(Presentation.createForWidthAndHeight(1920, 1080, Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP))
        }
        when (idx(lookG)) {
            1 -> {
                fx.add(Contrast(0.15f))
                fx.add(HslAdjustment.Builder().adjustSaturation(22f).build())
            }
            2 -> {
                fx.add(Contrast(0.2f))
                fx.add(HslAdjustment.Builder().adjustSaturation(6f).build())
                fx.add(RgbAdjustment.Builder().setRedScale(1.05f).setBlueScale(0.95f).build())
            }
            3 -> {
                fx.add(Contrast(0.12f))
                fx.add(HslAdjustment.Builder().adjustSaturation(35f).adjustLightness(4f).build())
            }
        }
        val portrait = f == 0 || (f == 2 && vh > vw)
        val ref = if (f == 2) minOf(vw, vh) else 1080
        val overlays = ArrayList<TextureOverlay>()
        if (capCb.isChecked && edit.phrases.isNotEmpty()) {
            overlays.add(CaptionOverlay(edit.phrases, (ref * 0.075f).toInt(), idx(capG), if (portrait) -0.3f else -0.7f))
        }
        if (edit.stickers.isNotEmpty()) overlays.add(EmojiOverlay(edit.stickers, (ref * 0.2f).toInt()))
        if (edit.images.isNotEmpty()) {
            val side = (ref * 0.38f).toInt()
            val bmps = libCache.map { x ->
                Library.bitmap(this, x)?.let { b ->
                    val m = maxOf(b.width, b.height)
                    if (m > side) Bitmap.createScaledBitmap(b, b.width * side / m, b.height * side / m, true) else b
                }
            }
            overlays.add(ImageOverlay(edit.images, bmps))
        }
        if (overlays.isNotEmpty()) fx.add(OverlayEffect(ImmutableList.copyOf(overlays)))

        val composition = Composition.Builder(EditedMediaItemSequence(items))
            .setEffects(Effects(emptyList(), fx))
            .build()
        val out = File(cacheDir, "proedit_" + System.currentTimeMillis() + ".mp4")
        outFile?.delete()
        outFile = out
        val removed = durMs - edit.totalMs
        val note = note0 + (if (removed > 1500) "Cut " + fmt(removed) + ". " else "") +
            (if (edit.phrases.isNotEmpty() && capCb.isChecked) edit.phrases.size.toString() + " caption lines. " else "") +
            (if (edit.stickers.isNotEmpty()) edit.stickers.size.toString() + " emoji. " else "") +
            (if (edit.images.isNotEmpty()) edit.images.size.toString() + " of your pictures. " else "")
        busy = true
        status.text = "4/4  Editing the video... keep the app open"
        val t = Transformer.Builder(this)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    setBusy(false, "Done! " + note)
                    video.visibility = View.VISIBLE
                    btnSave.visibility = View.VISIBLE
                    btnShare.visibility = View.VISIBLE
                    video.setVideoPath(out.absolutePath)
                    video.setMediaController(MediaController(this@MainActivity))
                    video.start()
                    if (plan != null) {
                        resultText = plan.title + "\n" + plan.desc + "\n" + plan.tags.joinToString(" ")
                        result.text = resultText
                        btnCopy.visibility = View.VISIBLE
                    }
                }

                override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                    setBusy(false, "Could not edit this video: " + exportException.message)
                }
            })
            .build()
        transformer = t
        t.start(composition, out.absolutePath)
    }

    private fun tick() {
        if (!busy) return
        val s = (System.currentTimeMillis() - startedAt) / 1000
        val base = status.text.toString().substringBefore("   [")
        status.text = base + "   [" + s + "s]"
        handler.postDelayed({ tick() }, 1000)
    }

    private fun cancel() {
        transformer?.cancel()
        setBusy(false, "Cancelled")
    }

    private fun save(share: Boolean) {
        var uri = savedUri
        if (uri == null) {
            val f = outFile ?: return
            val v = ContentValues()
            v.put(MediaStore.Video.Media.DISPLAY_NAME, "ProEdit_" + System.currentTimeMillis() + ".mp4")
            v.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            v.put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/ProEdit")
            v.put(MediaStore.Video.Media.IS_PENDING, 1)
            uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v)
            if (uri == null) {
                Toast.makeText(this, "Could not save", Toast.LENGTH_LONG).show()
                return
            }
            contentResolver.openOutputStream(uri)?.use { o -> f.inputStream().use { it.copyTo(o) } }
            v.clear()
            v.put(MediaStore.Video.Media.IS_PENDING, 0)
            contentResolver.update(uri, v, null, null)
            savedUri = uri
            Toast.makeText(this, "Saved in Movies/ProEdit", Toast.LENGTH_SHORT).show()
        }
        if (share) {
            val i = Intent(Intent.ACTION_SEND)
            i.type = "video/mp4"
            i.putExtra(Intent.EXTRA_STREAM, uri)
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(i, "Share video"))
        }
    }

    override fun onDestroy() {
        busy = false
        transformer?.cancel()
        super.onDestroy()
    }
}
