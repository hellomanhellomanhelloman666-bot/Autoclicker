package com.proeditor.app

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.nio.ByteOrder
import kotlin.math.log10
import kotlin.math.sqrt

// The "smart" part: listens to the audio and finds the quiet, boring parts.
object Analyzer {
    private const val WIN_MS = 100

    // Loudness in dB for every 100 ms, or null when the video has no readable audio.
    fun levels(ctx: Context, uri: Uri, durMs: Long): FloatArray? {
        val ex = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            ex.setDataSource(ctx, uri, null)
            var track = -1
            var fmt: MediaFormat? = null
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                val m = f.getString(MediaFormat.KEY_MIME) ?: continue
                if (m.startsWith("audio/")) {
                    track = i
                    fmt = f
                    break
                }
            }
            if (track < 0 || fmt == null) return null
            ex.selectTrack(track)
            val c = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!)
            codec = c
            c.configure(fmt, null, null, 0)
            c.start()
            val n = (durMs / WIN_MS + 3).toInt()
            val sum = DoubleArray(n)
            val cnt = LongArray(n)
            var rate = if (fmt.containsKey(MediaFormat.KEY_SAMPLE_RATE)) fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE) else 44100
            var ch = if (fmt.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 2
            val info = MediaCodec.BufferInfo()
            var inDone = false
            var outDone = false
            var guard = 0
            while (!outDone && guard < 3_000_000) {
                guard++
                if (!inDone) {
                    val ib = c.dequeueInputBuffer(5000)
                    if (ib >= 0) {
                        val buf = c.getInputBuffer(ib)!!
                        val size = ex.readSampleData(buf, 0)
                        if (size < 0) {
                            c.queueInputBuffer(ib, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inDone = true
                        } else {
                            c.queueInputBuffer(ib, 0, size, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                val ob = c.dequeueOutputBuffer(info, 5000)
                if (ob >= 0) {
                    if (info.size > 0) {
                        val buf = c.getOutputBuffer(ob)!!
                        buf.position(info.offset)
                        buf.limit(info.offset + info.size)
                        val sb = buf.order(ByteOrder.nativeOrder()).asShortBuffer()
                        val total = sb.remaining()
                        val perSec = rate.toDouble() * ch
                        for (k in 0 until total) {
                            val v = sb.get().toDouble()
                            val tUs = info.presentationTimeUs + (k * 1_000_000.0 / perSec).toLong()
                            val w = (tUs / 1000 / WIN_MS).toInt()
                            if (w in 0 until n) {
                                sum[w] += v * v
                                cnt[w]++
                            }
                        }
                    }
                    c.releaseOutputBuffer(ob, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outDone = true
                } else if (ob == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val outF = c.outputFormat
                    if (outF.containsKey(MediaFormat.KEY_SAMPLE_RATE)) rate = outF.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    if (outF.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) ch = outF.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                }
            }
            return FloatArray(n) { i ->
                if (cnt[i] == 0L) -100f
                else (20.0 * log10(sqrt(sum[i] / cnt[i]) / 32768.0 + 1e-9)).toFloat()
            }
        } catch (e: Exception) {
            return null
        } finally {
            try {
                codec?.stop()
                codec?.release()
            } catch (e: Exception) {
            }
            ex.release()
        }
    }

    // Returns the parts to KEEP, as [startMs, endMs]. If there is nothing clear to cut, keeps everything.
    fun plan(ctx: Context, uri: Uri, durMs: Long): List<LongArray> {
        val whole = listOf(longArrayOf(0L, durMs))
        val db = levels(ctx, uri, durMs) ?: return whole
        val real = db.filter { it > -99f }.sorted()
        if (real.size < 30) return whole
        val floor = real[(real.size * 0.15).toInt()]
        val peak = real[(real.size * 0.9).toInt()]
        if (peak - floor < 8f) return whole          // no clear difference between talking and silence
        val thr = floor + (peak - floor) * 0.35f
        val act = BooleanArray(db.size) { db[it] > thr }
        var i = 0
        while (i < act.size) {                       // bridge short pauses (under 0.8 s)
            if (!act[i]) {
                var j = i
                while (j < act.size && !act[j]) j++
                if (i > 0 && j < act.size && j - i < 8) for (k in i until j) act[k] = true
                i = j
            } else i++
        }
        val segs = ArrayList<LongArray>()
        i = 0
        while (i < act.size) {
            if (act[i]) {
                var j = i
                while (j < act.size && act[j]) j++
                if (j - i >= 4) segs.add(longArrayOf(maxOf(0L, (i - 2) * 100L), minOf(durMs, (j + 2) * 100L)))
                i = j
            } else i++
        }
        val merged = ArrayList<LongArray>()
        for (s in segs) {
            val l = merged.lastOrNull()
            if (l != null && s[0] <= l[1]) l[1] = maxOf(l[1], s[1]) else merged.add(s)
        }
        var kept = 0L
        for (m in merged) kept += m[1] - m[0]
        if (merged.isEmpty() || kept > durMs * 0.97 || kept < durMs * 0.15) return whole
        return merged
    }
}
