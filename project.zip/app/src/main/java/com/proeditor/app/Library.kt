package com.proeditor.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class Item(val file: String, val words: List<String>)

// Your own sticker / green-screen images, tagged with trigger words (for example "apple").
object Library {
    private fun dir(ctx: Context): File {
        val d = File(ctx.filesDir, "stickers")
        d.mkdirs()
        return d
    }

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("lib", Context.MODE_PRIVATE)

    fun norm(w: String): String = w.lowercase().filter { it.isLetter() }

    fun variants(w: String): List<String> {
        val x = norm(w)
        val out = arrayListOf(x)
        if (x.endsWith("es")) out.add(x.dropLast(2))
        if (x.endsWith("s")) out.add(x.dropLast(1))
        if (x.startsWith("ال") && x.length > 4) out.add(x.drop(2))
        return out
    }

    fun load(ctx: Context): MutableList<Item> {
        val out = ArrayList<Item>()
        try {
            val a = JSONArray(prefs(ctx).getString("items", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val w = o.getJSONArray("words")
                val ws = ArrayList<String>()
                for (k in 0 until w.length()) ws.add(w.getString(k))
                out.add(Item(o.getString("file"), ws))
            }
        } catch (e: Exception) {
        }
        return out
    }

    private fun save(ctx: Context, l: List<Item>) {
        val a = JSONArray()
        for (x in l) a.put(JSONObject().put("file", x.file).put("words", JSONArray(x.words)))
        prefs(ctx).edit().putString("items", a.toString()).apply()
    }

    fun add(ctx: Context, bmp: Bitmap, words: List<String>) {
        val name = "s" + System.currentTimeMillis() + ".png"
        File(dir(ctx), name).outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        val l = load(ctx)
        l.add(Item(name, words))
        save(ctx, l)
    }

    fun remove(ctx: Context, i: Int) {
        val l = load(ctx)
        if (i in l.indices) {
            File(dir(ctx), l[i].file).delete()
            l.removeAt(i)
            save(ctx, l)
        }
    }

    fun bitmap(ctx: Context, x: Item): Bitmap? = BitmapFactory.decodeFile(File(dir(ctx), x.file).absolutePath)

    fun decode(ctx: Context, uri: Uri, maxSide: Int): Bitmap? {
        val o = BitmapFactory.Options()
        o.inJustDecodeBounds = true
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        var s = 1
        while (maxOf(o.outWidth, o.outHeight) / s > maxSide * 2) s *= 2
        val o2 = BitmapFactory.Options()
        o2.inSampleSize = s
        val b = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) } ?: return null
        val m = maxOf(b.width, b.height)
        val sc = if (m > maxSide) Bitmap.createScaledBitmap(b, b.width * maxSide / m, b.height * maxSide / m, true) else b
        return sc.copy(Bitmap.Config.ARGB_8888, true)
    }

    private fun greenness(c: Int): Int {
        val r = (c shr 16) and 255
        val g = (c shr 8) and 255
        val b = c and 255
        return g - maxOf(r, b)
    }

    // True when the corners look like a green screen.
    fun greenCorners(b: Bitmap): Boolean {
        var n = 0
        val xs = intArrayOf(0, b.width - 1, 0, b.width - 1)
        val ys = intArrayOf(0, 0, b.height - 1, b.height - 1)
        for (i in 0..3) if (greenness(b.getPixel(xs[i], ys[i])) > 40) n++
        return n >= 3
    }

    // Removes the green background (chroma key) and cleans the green edges.
    fun chroma(src: Bitmap): Bitmap {
        val w = src.width
        val h = src.height
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        for (i in px.indices) {
            val c = px[i]
            val r = (c shr 16) and 255
            val g = (c shr 8) and 255
            val b = c and 255
            val dom = g - maxOf(r, b)
            if (dom > 40) {
                px[i] = 0
            } else if (dom > 12) {
                val a = 255 * (40 - dom) / 28
                val ng = minOf(g, maxOf(r, b))
                px[i] = (a shl 24) or (r shl 16) or (ng shl 8) or b
            } else {
                px[i] = (0xFF shl 24) or (c and 0x00FFFFFF)
            }
        }
        return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
    }
}
