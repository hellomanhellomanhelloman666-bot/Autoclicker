package com.autoclicker.app

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.TextView

// The UI: floating menu you can drag and resize.
class FloatingMenuService : Service() {

    private lateinit var wm: WindowManager
    private lateinit var root: View
    private lateinit var lp: WindowManager.LayoutParams
    private lateinit var tvTarget: TextView
    private lateinit var tvStatus: TextView
    private lateinit var etCount: EditText
    private lateinit var etSpeed: EditText
    private var tx = -1f
    private var ty = -1f

    override fun onBind(intent: Intent?): IBinder? = null

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        root = LayoutInflater.from(this).inflate(R.layout.menu, null)

        lp = WindowManager.LayoutParams(
            dp(280),
            dp(340),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = dp(20)
        lp.y = dp(120)
        wm.addView(root, lp)

        tvTarget = root.findViewById(R.id.tvTarget)
        tvStatus = root.findViewById(R.id.tvStatus)
        etCount = root.findViewById(R.id.etCount)
        etSpeed = root.findViewById(R.id.etSpeed)

        makeDrag(root.findViewById(R.id.title), false)
        makeDrag(root.findViewById(R.id.handle), true)

        for (et in listOf(etCount, etSpeed)) {
            et.setOnTouchListener { _, e ->
                if (e.action == MotionEvent.ACTION_DOWN) setFocusable(true)
                false
            }
            et.setOnEditorActionListener { v, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_DONE) {
                    hideKeyboard(v)
                    setFocusable(false)
                }
                true
            }
        }

        root.findViewById<Button>(R.id.btnPick).setOnClickListener {
            unfocus()
            pickSpot()
        }
        root.findViewById<Button>(R.id.btnOn).setOnClickListener {
            unfocus()
            turnOn()
        }
        root.findViewById<Button>(R.id.btnStop).setOnClickListener {
            unfocus()
            ClickEngine.stop()
        }
        root.findViewById<Button>(R.id.btnBack).setOnClickListener {
            unfocus()
            ClickEngine.resume()
        }
        root.findViewById<Button>(R.id.btnDelete).setOnClickListener {
            // Delete = cancel every clicker AND remove the menu for good.
            ClickEngine.deleteAll("Deleted")
            stopSelf()
        }

        ClickEngine.onStatus = { text -> tvStatus.text = text }
    }

    private fun turnOn() {
        if (tx < 0f) {
            tvStatus.text = "Pick a spot first"
            return
        }
        var count = etCount.text.toString().toIntOrNull() ?: 10
        if (count < 1) count = 1
        if (count > 100000) count = 100000
        var ms = etSpeed.text.toString().toLongOrNull() ?: 100L
        if (ms < ClickEngine.MIN_MS) {
            ms = ClickEngine.MIN_MS
            etSpeed.setText(ms.toString())
        }
        ClickEngine.start(tx, ty, count, ms)
    }

    private fun pickSpot() {
        val overlay = FrameLayout(this)
        overlay.setBackgroundColor(0x66000000)
        val hint = TextView(this)
        hint.text = "Tap where you want the clicks"
        hint.setTextColor(Color.WHITE)
        hint.textSize = 20f
        hint.gravity = Gravity.CENTER
        overlay.addView(
            hint,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )
        val p = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        overlay.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_UP) {
                tx = e.rawX
                ty = e.rawY
                tvTarget.text = "Spot: ${tx.toInt()}, ${ty.toInt()}"
                wm.removeView(overlay)
            }
            true
        }
        wm.addView(overlay, p)
    }

    private fun makeDrag(v: View, resize: Boolean) {
        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX
                    sy = e.rawY
                    if (resize) {
                        ox = lp.width
                        oy = lp.height
                    } else {
                        ox = lp.x
                        oy = lp.y
                    }
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - sx).toInt()
                    val dy = (e.rawY - sy).toInt()
                    if (resize) {
                        lp.width = maxOf(dp(160), ox + dx)
                        lp.height = maxOf(dp(140), oy + dy)
                    } else {
                        lp.x = ox + dx
                        lp.y = oy + dy
                    }
                    wm.updateViewLayout(root, lp)
                }
            }
            true
        }
    }

    private fun setFocusable(focusable: Boolean) {
        lp.flags = if (focusable) {
            lp.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
        } else {
            lp.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        }
        wm.updateViewLayout(root, lp)
    }

    private fun hideKeyboard(v: View) {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(v.windowToken, 0)
    }

    private fun unfocus() {
        hideKeyboard(root)
        setFocusable(false)
    }

    override fun onDestroy() {
        ClickEngine.onStatus = null
        try {
            wm.removeView(root)
        } catch (e: Exception) {
        }
        super.onDestroy()
    }
}
