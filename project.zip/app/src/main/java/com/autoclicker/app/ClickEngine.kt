package com.autoclicker.app

import android.os.Handler
import android.os.Looper
import android.os.SystemClock

// The auto script: many clickers at once, speed limit, stop / back / delete.
object ClickEngine {

    // Speed limit. Nobody can go faster than this (protects the phone).
    const val MIN_MS = 40L
    private const val MAX_TASKS = 20

    private class Task(val x: Float, val y: Float, var left: Int, val ms: Long)

    private val handler = Handler(Looper.getMainLooper())
    private val tasks = mutableListOf<Task>()
    private var paused = false

    var onStatus: ((String) -> Unit)? = null

    fun start(x: Float, y: Float, count: Int, ms: Long) {
        if (tasks.size >= MAX_TASKS) {
            report("Too many clickers (max $MAX_TASKS)")
            return
        }
        val safeMs = if (ms < MIN_MS) MIN_MS else ms
        val task = Task(x, y, count, safeMs)
        tasks.add(task)
        paused = false
        schedule(task, SystemClock.uptimeMillis() + safeMs)
        report(null)
    }

    private fun schedule(task: Task, at: Long) {
        handler.postAtTime(Runnable { step(task, at) }, at)
    }

    private fun step(task: Task, due: Long) {
        if (!tasks.contains(task)) return
        val now = SystemClock.uptimeMillis()

        // Freeze protection: if the phone is lagging badly, stop everything.
        if (now - due > 1500) {
            deleteAll("Phone lagged - auto stopped")
            return
        }
        if (paused) {
            schedule(task, now + 200)
            return
        }
        val service = ClickService.instance
        if (service == null) {
            deleteAll("Turn on Accessibility first")
            return
        }
        service.tap(task.x, task.y)
        task.left--
        if (task.left <= 0) {
            tasks.remove(task)
            report(null)
        } else {
            schedule(task, now + task.ms)
        }
    }

    fun stop() {
        paused = true
        report(null)
    }

    fun resume() {
        paused = false
        report(null)
    }

    fun deleteAll(message: String?) {
        handler.removeCallbacksAndMessages(null)
        tasks.clear()
        paused = false
        report(message ?: "Deleted")
    }

    private fun report(message: String?) {
        val text = message ?: if (tasks.isEmpty()) {
            "Idle"
        } else {
            "Running: ${tasks.size}" + if (paused) " (stopped)" else ""
        }
        onStatus?.invoke(text)
    }
}
