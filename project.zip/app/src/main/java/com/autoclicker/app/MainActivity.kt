package com.autoclicker.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

// The first screen: permissions + show the menu.
class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this)
        layout.orientation = LinearLayout.VERTICAL
        layout.setPadding(40, 80, 40, 40)

        val info = TextView(this)
        info.text = "Do the 3 steps in order:"
        info.textSize = 18f
        layout.addView(info)

        val about = TextView(this)
        about.text = "What this app does:\n" +
            "- Press ON in the menu, then tap anywhere: that spot is clicked as many times as you typed.\n" +
            "- It has NO internet permission. It cannot send anything out.\n" +
            "- It cannot read your screen, messages or passwords.\n" +
            "- Max 10000 taps, minimum 40ms delay, stops by itself after 10 minutes.\n" +
            "- Emergency stop: Settings > Accessibility > AutoClicker > Off."
        about.setPadding(0, 20, 0, 20)
        layout.addView(about)

        val agree = CheckBox(this)
        agree.text = "I understand and I allow this"
        layout.addView(agree)

        fun addButton(label: String, action: () -> Unit) {
            val b = Button(this)
            b.text = label
            b.setOnClickListener { action() }
            layout.addView(b)
        }

        addButton("1) Allow display over other apps") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        }
        addButton("2) Turn on Accessibility (find AutoClicker)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        addButton("3) Show the menu") {
            if (!agree.isChecked) {
                Toast.makeText(this, "Tick the box first", Toast.LENGTH_LONG).show()
            } else if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Do step 1 first", Toast.LENGTH_LONG).show()
            } else {
                startService(Intent(this, FloatingMenuService::class.java))
                moveTaskToBack(true)
            }
        }
        setContentView(layout)
    }
}
