package com.tikcraft.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocketListener
import org.java_websocket.handshake.ClientHandshake
import org.java_websocket.server.WebSocketServer
import org.json.JSONArray
import org.json.JSONObject
import java.net.InetSocketAddress
import java.net.URLEncoder
import java.util.Random
import java.util.UUID
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import org.java_websocket.WebSocket as McSocket

class Rule(val on: String, val n: Int, val gift: String, val cmd: String, val count: Int)

// Keeps running while you play: listens to TikTok, sends commands to Minecraft.
class LiveService : Service() {

    companion object {
        const val PORT = 19131
        @Volatile var running = false
        @Volatile var status = "Stopped"
        @Volatile var mc = false
        @Volatile var instance: LiveService? = null
        private val logs = ArrayDeque<String>()

        fun log(s: String) {
            synchronized(logs) {
                logs.addFirst(s)
                while (logs.size > 25) logs.removeLast()
            }
        }

        fun stateJson(): String {
            val o = JSONObject()
            o.put("running", running)
            o.put("status", status)
            o.put("mc", mc)
            synchronized(logs) { o.put("log", JSONArray(logs.toList())) }
            return o.toString()
        }
    }

    private var rules = listOf<Rule>()
    private var acc = LongArray(0)
    private var server: WebSocketServer? = null
    @Volatile private var mcSock: McSocket? = null
    private var tt: okhttp3.WebSocket? = null
    private val http = OkHttpClient.Builder().pingInterval(25, TimeUnit.SECONDS).build()
    private val ex = Executors.newSingleThreadScheduledExecutor()
    private val q = ConcurrentLinkedQueue<String>()
    private var wake: PowerManager.WakeLock? = null
    private var user = ""
    private var key = ""
    private val rnd = Random()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        // Send one queued command every 0.3s so Minecraft never gets flooded.
        ex.scheduleWithFixedDelay({
            try {
                val c = q.poll()
                if (c != null) send(c)
            } catch (e: Exception) {
            }
        }, 0, 300, TimeUnit.MILLISECONDS)
    }

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        startFg()
        if (i == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        user = (i.getStringExtra("user") ?: "").trim().removePrefix("@")
        key = (i.getStringExtra("key") ?: "").trim()
        val arr = JSONArray(i.getStringExtra("rules") ?: "[]")
        rules = (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Rule(o.optString("on"), o.optInt("n", 0), o.optString("gift"), o.optString("cmd"), o.optInt("count", 1))
        }
        acc = LongArray(rules.size)
        Thread { begin() }.start()
        return START_NOT_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("live", "Live link", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "live")
            .setContentTitle("TikCraft Live is running")
            .setContentText("Linking TikTok Live to Minecraft")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(1, n)
        }
    }

    @Synchronized
    private fun begin() {
        closeAll()
        running = true
        instance = this
        status = "Starting..."
        wake = (getSystemService(POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "tikcraft:live")
        wake?.acquire(6 * 60 * 60 * 1000L)
        try {
            val s = object : WebSocketServer(InetSocketAddress("127.0.0.1", PORT)) {
                override fun onOpen(conn: McSocket, handshake: ClientHandshake) {
                    mcSock = conn
                    mc = true
                    log("Minecraft connected")
                    q.add("say TikCraft Live is linked!")
                }

                override fun onClose(conn: McSocket, code: Int, reason: String, remote: Boolean) {
                    if (mcSock === conn) {
                        mcSock = null
                        mc = false
                    }
                    log("Minecraft disconnected")
                }

                override fun onMessage(conn: McSocket, message: String) {}

                override fun onError(conn: McSocket?, e: Exception) {
                    log("Minecraft link error: " + e.message)
                }

                override fun onStart() {
                    log("Waiting for Minecraft on port $PORT")
                }
            }
            s.isReuseAddr = true
            s.start()
            server = s
        } catch (e: Exception) {
            log("Could not open Minecraft port: " + e.message)
        }
        connectTT()
    }

    private fun connectTT() {
        if (!running) return
        val url = "wss://api.tik.tools?uniqueId=" + URLEncoder.encode(user, "UTF-8") +
            "&apiKey=" + URLEncoder.encode(key, "UTF-8")
        status = "Connecting to TikTok service..."
        tt = http.newWebSocket(Request.Builder().url(url).build(), object : WebSocketListener() {
            override fun onOpen(webSocket: okhttp3.WebSocket, response: Response) {
                status = "Connected. Waiting for gifts and likes"
                log("TikTok service connected")
            }

            override fun onMessage(webSocket: okhttp3.WebSocket, text: String) {
                handle(text)
            }

            override fun onClosed(webSocket: okhttp3.WebSocket, code: Int, reason: String) {
                retry("closed ($code)")
            }

            override fun onFailure(webSocket: okhttp3.WebSocket, t: Throwable, response: Response?) {
                val c = response?.code ?: 0
                if (c in 400..499) {
                    status = "TikTok service refused ($c). Check username, API key, and that you are LIVE"
                    log(status)
                } else {
                    retry(t.message ?: "error")
                }
            }
        })
    }

    private fun retry(why: String) {
        if (!running) return
        status = "TikTok: $why. Reconnecting..."
        log(status)
        ex.schedule({ connectTT() }, 4, TimeUnit.SECONDS)
    }

    private fun clean(s: String): String =
        s.filter { it.isLetterOrDigit() || it == '_' || it == '.' }.take(20)

    private fun handle(text: String) {
        try {
            val m = JSONObject(text)
            val ev = m.optString("event", m.optString("type", ""))
            val d = m.optJSONObject("data") ?: m
            val who = clean(d.optJSONObject("user")?.optString("uniqueId") ?: "")
            when (ev) {
                "gift" -> {
                    val name = d.optString("giftName", "gift")
                    val re = d.opt("repeatEnd")
                    val ended = when (re) {
                        is Boolean -> re
                        is Number -> re.toInt() != 0
                        else -> true
                    }
                    if (d.optInt("giftType", 0) == 1 && !ended) return
                    log("$who sent $name")
                    if (q.size < 200) q.add("title @a actionbar " + "\u00a7e" + who + " sent " + clean(name))
                    for (r in rules) {
                        if (r.on == "gift" && (r.gift.isBlank() || name.contains(r.gift, true))) spawn(r.cmd, r.count)
                    }
                }
                "like" -> {
                    val c = d.optInt("likeCount", 1).coerceAtLeast(1)
                    for ((i, r) in rules.withIndex()) {
                        if (r.on == "likes" && r.n > 0) {
                            val step = r.n.toLong()
                            var total: Long = acc[i] + c.toLong()
                            var f = 0
                            while (total >= step && f < 10) {
                                total = total - step
                                f++
                                spawn(r.cmd, r.count)
                            }
                            if (f == 10) total = 0L
                            acc[i] = total
                        }
                    }
                }
                "connected", "disconnected", "error" -> log("TikTok: " + text.take(90))
            }
        } catch (e: Exception) {
        }
    }

    private fun off(): Int = (if (rnd.nextBoolean()) 1 else -1) * (2 + rnd.nextInt(3))

    fun spawn(cmd: String, count: Int) {
        repeat(count.coerceIn(1, 10)) {
            var c = cmd.trim().removePrefix("/")
            if (c.isEmpty()) return
            val p = c.split(" ")
            if (p[0] == "summon" && p.size == 2) c = c + " ~" + off() + " ~1 ~" + off()
            if (q.size < 200) q.add(c)
        }
    }

    private fun send(c: String) {
        val s = mcSock
        if (s == null || !s.isOpen) return
        val h = JSONObject().put("version", 1).put("requestId", UUID.randomUUID().toString())
            .put("messagePurpose", "commandRequest").put("messageType", "commandRequest")
        val b = JSONObject().put("origin", JSONObject().put("type", "player"))
            .put("commandLine", c).put("version", 1)
        s.send(JSONObject().put("header", h).put("body", b).toString())
    }

    private fun closeAll() {
        tt?.cancel()
        tt = null
        try {
            server?.stop(100)
        } catch (e: Exception) {
        }
        server = null
        mcSock = null
        mc = false
        q.clear()
        try {
            if (wake?.isHeld == true) wake?.release()
        } catch (e: Exception) {
        }
    }

    override fun onDestroy() {
        running = false
        status = "Stopped"
        instance = null
        ex.shutdownNow()
        Thread { closeAll() }.start()
        super.onDestroy()
    }
}
