# Code Studio — mobile and web starter

Upload the contents of this folder to GitHub. For offline/PWA behavior, serve on HTTPS or localhost; opening as a raw file does not enable service workers.

## Included
- Responsive dark editor with line numbers, indentation, symbol toolbar, file tree, templates in starter files, local save.
- Sandboxed iframe preview for HTML/CSS/JavaScript, console forwarding, basic error explanation.
- ZIP project export and standalone HTML export; manifest and service worker for PWA caching.
- Local snapshot/commit list.

## Limitations (important)
This is a functional starter, not a full professional IDE. The editor is a textarea, not Monaco/CodeMirror. Python and Lua/Luau interpreter runtimes are not included. AI explanations are rule-based and offline; cloud AI requires a secure backend. Browser sandboxing reduces access to the parent app but does not prevent all resource exhaustion. Export creates a web app/PWA, not a native Android APK. For APKs, wrap the project with Capacitor and build with Android tooling.
