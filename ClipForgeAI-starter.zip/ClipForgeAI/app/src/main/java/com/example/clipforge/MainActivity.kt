package com.example.clipforge

import android.content.ContentResolver
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.OpenableColumns
import android.widget.MediaController
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.FileProvider
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.Presentation
import androidx.media3.effect.StaticOverlaySettings
import androidx.media3.effect.TextOverlay
import androidx.media3.effect.TextureOverlay
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import android.text.SpannableString
import android.text.style.ForegroundColorSpan
import android.text.Spanned
import java.io.File

private val Background = Color(0xFF0B0B12)
private val Panel = Color(0xFF171723)
private val Accent = Color(0xFF9B7BFF)
private val SoftText = Color(0xFFB9B7C8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = Background) {
                    EditorHome(
                        onExport = { uri, format, style, status ->
                            exportVideo(uri, format, style, status)
                        },
                        onShare = { file -> shareVideo(file) }
                    )
                }
            }
        }
    }

    @OptIn(UnstableApi::class)
    private fun exportVideo(
        inputUri: Uri,
        format: String,
        style: String,
        onStatus: (String) -> Unit
    ) {
        val exportDirectory = getExternalFilesDir(Environment.DIRECTORY_MOVIES)
        if (exportDirectory == null) {
            onStatus("Couldn't access the export folder. Try again.")
            return
        }
        if (!exportDirectory.exists() && !exportDirectory.mkdirs()) {
            onStatus("Couldn't create the export folder. Try again.")
            return
        }

        val outputFile = File(exportDirectory, "ClipForge_${System.currentTimeMillis()}.mp4")
        val overlayLabel = when (style) {
            "Gaming" -> "GAMEPLAY HIGHLIGHT  ✦"
            "Cinematic" -> "CINEMATIC EDIT"
            else -> "WAIT FOR IT  💀"
        }
        val width = if (format == "Shorts / TikTok · 9:16") 1080 else 1920
        val height = if (format == "Shorts / TikTok · 9:16") 1920 else 1080

        val styledText = SpannableString(overlayLabel).apply {
            setSpan(ForegroundColorSpan(android.graphics.Color.WHITE), 0, length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        val overlay = TextOverlay.createStaticTextOverlay(
            styledText,
            StaticOverlaySettings.Builder().build()
        )
        val videoEffects: List<androidx.media3.common.Effect> = listOf(
            Presentation.createForWidthAndHeight(
                width,
                height,
                Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP
            ),
            OverlayEffect(listOf<TextureOverlay>(overlay))
        )
        val editedItem = EditedMediaItem.Builder(MediaItem.fromUri(inputUri))
            .setEffects(Effects(emptyList(), videoEffects))
            .build()

        onStatus("Rendering your edit… keep the app open while it exports.")
        val transformer = Transformer.Builder(this)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    runOnUiThread {
                        onStatus("Export complete! Your video is ready to share.")
                        latestExport = outputFile
                    }
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    runOnUiThread {
                        outputFile.delete()
                        onStatus("Export failed on this video. Try a shorter MP4 file. Details: ${exportException.errorCodeName}")
                    }
                }
            })
            .build()

        latestExport = null
        try {
            transformer.start(editedItem, outputFile.absolutePath)
        } catch (error: Exception) {
            outputFile.delete()
            onStatus("Couldn't start editing: ${error.message ?: "unknown error"}")
        }
    }

    private var latestExport: File? = null

    private fun shareVideo(file: File?) {
        if (file == null || !file.exists()) return
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        val sendIntent = Intent(Intent.ACTION_SEND).apply {
            type = "video/mp4"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(sendIntent, "Share your edited video"))
    }
}

@Composable
private fun EditorHome(
    onExport: (Uri, String, String, (String) -> Unit) -> Unit,
    onShare: (File?) -> Unit
) {
    val context = LocalContext.current
    var videoUri by remember { mutableStateOf<Uri?>(null) }
    var videoName by remember { mutableStateOf<String?>(null) }
    var format by remember { mutableStateOf("Shorts / TikTok · 9:16") }
    var style by remember { mutableStateOf("Gaming") }
    var exportStatus by remember { mutableStateOf("Choose a video to start your first edit.") }
    var isExporting by remember { mutableStateOf(false) }
    var exportFinished by remember { mutableStateOf(false) }
    var latestFile by remember { mutableStateOf<File?>(null) }

    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            videoUri = uri
            videoName = queryDisplayName(context.contentResolver, uri)
            exportStatus = "Video loaded. Pick your format and style, then tap Auto Edit."
            exportFinished = false
            latestFile = null
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .background(Background)
            .padding(horizontal = 18.dp, vertical = 22.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .width(46.dp)
                    .height(46.dp)
                    .background(Accent, RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text("✦", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Black)
            }
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text("CLIPFORGE AI", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black)
                Text("RAW CLIPS → BETTER EDITS", color = SoftText, fontSize = 10.sp, letterSpacing = 1.6.sp)
            }
            Surface(color = Color(0xFF242035), shape = RoundedCornerShape(50)) {
                Text("BETA", color = Accent, fontSize = 10.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp))
            }
        }

        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("Your video.\nA whole new edit.", color = Color.White, fontSize = 30.sp, lineHeight = 35.sp, fontWeight = FontWeight.ExtraBold)
            Text("Choose a clip, pick a vibe, and export a styled edit.", color = SoftText, fontSize = 14.sp)
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = Panel),
            shape = RoundedCornerShape(22.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("YOUR FOOTAGE", color = SoftText, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                val selectedUri = videoUri
                if (selectedUri != null) {
                    AndroidView(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(210.dp)
                            .background(Color.Black, RoundedCornerShape(14.dp)),
                        factory = { viewContext ->
                            VideoView(viewContext).apply {
                                setVideoURI(selectedUri)
                                setMediaController(MediaController(viewContext).also { it.setAnchorView(this) })
                            }
                        },
                        update = { view ->
                            if (view.tag != selectedUri.toString()) {
                                view.tag = selectedUri.toString()
                                view.setVideoURI(selectedUri)
                            }
                        }
                    )
                    Text(videoName ?: "Selected video", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                            .background(Color(0xFF101019), RoundedCornerShape(14.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("▶", color = Accent, fontSize = 34.sp)
                            Text("Your next edit starts here", color = Color.White, fontWeight = FontWeight.SemiBold)
                            Text("MP4 videos work best for this prototype", color = SoftText, fontSize = 11.sp)
                        }
                    }
                }
                Button(
                    onClick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF28233A)),
                    shape = RoundedCornerShape(13.dp)
                ) {
                    Text(if (selectedUri == null) "＋  Choose a video" else "↻  Change video", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }

        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            SectionHeading("01", "CHOOSE OUTPUT")
            Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                ChoiceCard(
                    title = "Shorts / TikTok",
                    subtitle = "Vertical · 9:16",
                    selected = format == "Shorts / TikTok · 9:16",
                    modifier = Modifier.weight(1f),
                    onClick = { format = "Shorts / TikTok · 9:16" }
                )
                ChoiceCard(
                    title = "YouTube",
                    subtitle = "Widescreen · 16:9",
                    selected = format == "YouTube · 16:9",
                    modifier = Modifier.weight(1f),
                    onClick = { format = "YouTube · 16:9" }
                )
            }
        }

        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            SectionHeading("02", "PICK YOUR STYLE")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Gaming", "Cinematic", "Meme").forEach { option ->
                    val selected = style == option
                    Button(
                        onClick = { style = option },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (selected) Accent else Panel,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(13.dp)
                    ) {
                        Text(when (option) { "Gaming" -> "🎮 Gaming"; "Cinematic" -> "🎞 Film"; else -> "😂 Meme" }, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        Button(
            onClick = {
                val uri = videoUri
                if (uri != null && !isExporting) {
                    isExporting = true
                    exportFinished = false
                    onExport(uri, format, style) { newStatus ->
                        exportStatus = newStatus
                        isExporting = newStatus.startsWith("Rendering")
                        exportFinished = newStatus.startsWith("Export complete")
                        if (exportFinished) {
                            // Output is saved in the app's Movies folder; use Share to select a destination.
                            val directory = context.getExternalFilesDir(Environment.DIRECTORY_MOVIES)
                            latestFile = directory?.listFiles()?.filter { it.name.startsWith("ClipForge_") && it.extension == "mp4" }?.maxByOrNull { it.lastModified() }
                        }
                    }
                } else if (uri == null) {
                    exportStatus = "Choose a video first, then Auto Edit."
                }
            },
            enabled = !isExporting,
            modifier = Modifier.fillMaxWidth().height(56.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Accent, disabledContainerColor = Color(0xFF484052)),
            shape = RoundedCornerShape(16.dp)
        ) {
            if (isExporting) {
                CircularProgressIndicator(color = Color.White, strokeWidth = 2.dp, modifier = Modifier.width(19.dp).height(19.dp))
                Spacer(Modifier.width(10.dp))
                Text("EXPORTING…", fontWeight = FontWeight.ExtraBold)
            } else {
                Text("✦  AUTO EDIT & EXPORT", fontSize = 15.sp, fontWeight = FontWeight.ExtraBold)
            }
        }

        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("EDIT STATUS", color = SoftText, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.3.sp)
                Text(exportStatus, color = Color.White, fontSize = 13.sp)
                if (exportFinished) {
                    OutlinedButton(
                        onClick = { onShare(latestFile) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) { Text("↗  Share finished video", color = Accent, fontWeight = FontWeight.Bold) }
                }
            }
        }

        Text(
            "PROTOTYPE NOTE  •  This version exports a styled video with an output crop and title overlay. Automatic scene detection, smart cuts, generated captions, and AI-selected effects are future features.",
            color = Color(0xFF8E8B9B), fontSize = 11.sp, lineHeight = 16.sp
        )
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun SectionHeading(number: String, title: String) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
        Text(number, color = Accent, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
        Text(title, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
    }
}

@Composable
private fun ChoiceCard(
    title: String,
    subtitle: String,
    selected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val bg = if (selected) Color(0xFF27213A) else Panel
    Card(
        onClick = onClick,
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = bg),
        shape = RoundedCornerShape(15.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, if (selected) Accent else Color(0xFF292938))
    ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(title, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Text(subtitle, color = if (selected) Accent else SoftText, fontSize = 11.sp)
        }
    }
}

private fun queryDisplayName(contentResolver: ContentResolver, uri: Uri): String? {
    return contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
        if (cursor.moveToFirst()) {
            val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (index >= 0) cursor.getString(index) else null
        } else null
    }
}
