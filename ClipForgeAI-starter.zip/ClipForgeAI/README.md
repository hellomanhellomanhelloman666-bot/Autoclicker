# ClipForge AI — Android starter prototype

ClipForge AI is a phone-first Android video editor prototype for making social-video exports from a selected video.

## What works in this starter

- Pick a video from the Android media picker.
- Preview the selected clip.
- Choose a vertical 9:16 or widescreen 16:9 output preset.
- Choose a Gaming, Cinematic, or Meme title style.
- Export an MP4 using AndroidX Media3 Transformer, with crop/scale and a title overlay.
- Share the exported MP4 with another app.
- Build a debug APK through GitHub Actions.

## What is not implemented yet

The word “AI” in the name describes the planned product direction, not a working AI model in this first prototype. This starter does **not** yet understand the footage, find exciting moments, auto-trim dead sections, generate accurate subtitles, or generate custom effects. The three styles currently choose a title overlay. Those features need a real analysis pipeline and should be added after the editing/export path is tested on a real phone.

## Build the APK from GitHub using a phone

1. Create a new empty repository on GitHub.
2. Download and unzip this project, then upload the **contents** of the `ClipForgeAI` folder to the repository root (the `.github` folder must be included).
3. Commit the files to the `main` branch.
4. Open the repository's **Actions** tab. The workflow named **Build Android APK** should start.
5. When it finishes successfully, open that run, find **Artifacts**, and download `ClipForgeAI-debug-apk`.
6. Unzip the artifact and install `app-debug.apk` on your Android phone. Android may ask you to permit installation from the browser or file app you used to download it; only install APKs you built and trust.

If the build fails, open the workflow log and copy the first actual error message; later errors may just be consequences of the first one.

## Technology

- Kotlin + Jetpack Compose
- AndroidX Media3 Transformer / Effect
- GitHub Actions build workflow

## Next development stages

1. Test import, render, sharing, and output aspect ratio with short sample clips.
2. Add a timeline model for multiple cuts and timed overlays.
3. Analyze scene changes and audio peaks to suggest edit points.
4. Add a speech-to-text pipeline for captions.
5. Add an AI service that returns a structured edit plan (cuts, zooms, overlays, sound effects) for the renderer to execute.
6. Add an editable preview so the user can approve or change AI suggestions before exporting.

## Important

Long video processing can use substantial battery, storage, and time. Test with a short clip first. Do not upload private footage to any AI service without understanding its privacy policy. Keep API keys out of the Android app and out of GitHub commits.
